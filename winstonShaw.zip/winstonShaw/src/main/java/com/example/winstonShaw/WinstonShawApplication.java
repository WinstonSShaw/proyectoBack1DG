package com.example.winstonShaw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WinstonShawApplication {

	public static void main(String[] args) {
		SpringApplication.run(WinstonShawApplication.class, args);
	}

}
