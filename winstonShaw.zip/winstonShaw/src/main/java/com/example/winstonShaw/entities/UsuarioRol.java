package com.example.winstonShaw.entities;

public enum UsuarioRol {
    ROLE_USER, ROLE_ADMIN;
}
