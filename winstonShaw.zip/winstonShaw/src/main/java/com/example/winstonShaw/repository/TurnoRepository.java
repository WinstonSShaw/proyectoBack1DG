package com.example.winstonShaw.repository;

import com.example.winstonShaw.entities.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TurnoRepository extends JpaRepository<Turno, Long> {
}
