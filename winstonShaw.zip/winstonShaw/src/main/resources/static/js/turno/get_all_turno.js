window.addEventListener('load', function () {
    (function(){

      //VER ODONTOLOGO
      const url = '/turnos';
      const settings = {
        method: 'GET'
      }

      fetch(url,settings)
      .then(response => response.json())
      .then(data => {
      //VER ODONTOLOGO
         for(turno of data){
            //VER ODONTOLOGO
            var table = document.getElementById("turnoTable");
            var turnoRow =table.insertRow();
            let tr_id = 'tr_' + turno.id;
            turnoRow.id = tr_id;

            let deleteLink='<a id=\"a_delete_'+turno.id+'\"'+
            ' href=\"#\" onclick=\"deleteBy('+turno.id+')\"'+
            ' class=\"link-danger\">Borrar</a>';

            //VER ODONTOLOGO
            turnoRow.innerHTML =
                    '<td class=\"td_id\">' + turno.id + '</td>' +
                    '<td class=\"td_pacienteId\">' + turno.paciente.id + '</td>' +
                    '<td class=\"td_pacienteApellido\">' + turno.paciente.apellido + '</td>' +
                    '<td class=\"td_odontologoId\">' + turno.odontologo.id + '</td>' +
                    '<td class=\"td_odontologoApellido\">' + turno.odontologo.apellido + '</td>' +
                    '<td class=\"td_fecha\">' + turno.fecha + '</td>'+
                    '<td>'+deleteLink+'</td>';

        };

    })
    })

    (function(){
          let pathname = window.location.pathname;
          if (pathname == "/peliculaList.html") {
              document.querySelector(".nav .nav-item a:last").addClass("active");
          }
    })


    })