window.addEventListener('load', function () {
    (function(){

      //VER ODONTOLOGO
      const url = '/pacientes';
      const settings = {
        method: 'GET'
      }

      fetch(url,settings)
      .then(response => response.json())
      .then(data => {
      //VER ODONTOLOGO
         for(paciente of data){
            //VER ODONTOLOGO
            var table = document.getElementById("pacienteTable");
            var pacienteRow =table.insertRow();
            let tr_id = 'tr_' + paciente.id;
            pacienteRow.id = tr_id;

            let deleteLink='<a id=\"a_delete_'+paciente.id+'\"'+
            ' href=\"#\" onclick=\"deleteBy('+paciente.id+')\"'+
            ' class=\"link-danger\">Borrar</a>';

            let updateButton='<button id=\"a_put_'+paciente.id+'\"'+
                                    'type="button" onClick="findBy('+paciente.id+')" class="btn btn-info btn_id">' +
                                    'Actualizar' + '</button>';

            //VER ODONTOLOGO
            pacienteRow.innerHTML =
                    '<td class=\"td_id\">' + paciente.id + '</td>' +
                    '<td class=\"td_apellido\">' + paciente.apellido.toUpperCase() + '</td>' +
                    '<td class=\"td_nombre\">' + paciente.nombre.toUpperCase() + '</td>' +
                    '<td class=\"td_dni\">' + paciente.dni + '</td>'+
                    '<td class=\"td_fechaIngreso\">' + paciente.fechaIngreso + '</td>'+
                    '<td class=\"td_id\">' + paciente.domicilio.id + '</td>' +
                    '<td class=\"td_calle\">' + paciente.domicilio.calle + '</td>'+
                    '<td class=\"td_numeroCalle\">' + paciente.domicilio.numero + '</td>'+
                    '<td class=\"td_localidad\">' + paciente.domicilio.localidad + '</td>'+
                    '<td class=\"td_provincia\">' + paciente.domicilio.provincia + '</td>'+
                    '<td>'+deleteLink+'</td>'+
                    '<td>'+updateButton+'</td>';

        };

    })
    })

    (function(){
      let pathname = window.location.pathname;
      if (pathname == "/peliculaList.html") {
          document.querySelector(".nav .nav-item a:last").addClass("active");
      }
    })


    })