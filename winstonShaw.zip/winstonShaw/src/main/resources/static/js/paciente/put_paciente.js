window.addEventListener('load', function () {


    //VER ODONTOLOGO
    const formulario = document.querySelector('#update_paciente_form');

    formulario.addEventListener('submit', function (event) {
        let pacienteId = document.querySelector('#paciente_idPut').value;
        let domicilioId = document.querySelector('#domicilio_idPut').value;

        //VER ODONTOLOGO
        const formData = {
            id: document.querySelector('#paciente_idPut').value,
            apellido: document.querySelector('#apellidoPut').value,
            nombre: document.querySelector('#nombrePut').value,
            dni: document.querySelector('#dniPut').value,
            fechaIngreso: document.querySelector('#fechaIngresoPut').value,
            domicilio:{
                id:document.querySelector('#domicilio_idPut').value,
                calle:document.querySelector('#callePut').value,
                numero:document.querySelector('#numeroCallePut').value,
                localidad:document.querySelector('#localidadPut').value,
                provincia:document.querySelector('#provinciaPut').value,
            }

        };

        //VER ODONTOLOGO
        const url = '/pacientes';
        const settings = {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        }
          fetch(url,settings)
          .then(response => response.json())

    })
 })

    //VER ODONTOLOGO
    function findBy(id) {
          const url = '/pacientes'+"/"+id;
          const settings = {
              method: 'GET'
          }
          fetch(url,settings)
          .then(response => response.json())
          .then(data => {
              let paciente = data;
              document.querySelector('#paciente_idPut').value = paciente.id;
              document.querySelector('#apellidoPut').value = paciente.apellido;
              document.querySelector('#nombrePut').value = paciente.nombre;
              document.querySelector('#dniPut').value = paciente.dni;
              document.querySelector('#fechaIngresoPut').value = paciente.fechaIngreso;
              document.querySelector('#domicilio_idPut').value = paciente.domicilio.id;
              document.querySelector('#callePut').value = paciente.domicilio.calle;
              document.querySelector('#numeroCallePut').value = paciente.domicilio.numero;
              document.querySelector('#localidadPut').value = paciente.domicilio.localidad;
              document.querySelector('#provinciaPut').value = paciente.domicilio.provincia;
              //VER ODONTOLOGO
              document.querySelector('#div_paciente_updating').style.display = "block";
          }).catch(error => {
              alert("Error: " + error);
          })
      }